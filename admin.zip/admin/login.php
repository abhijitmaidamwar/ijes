<?php
include 'lib/session.php';
// ob_start();

if($_SESSION['memberId'] != NULL && $_SESSION['memberType'] == 1){
	header('location:admin/');
}

if($_SESSION['memberId'] != NULL && $_SESSION['memberType'] == 2){
	header('location:dashboard/');
}

$lib = new library; 

$basename = $lib -> hostname();
$assets = $lib -> hostmain();

if(isset($_POST['sublog'])){

	$dataname = "users";	
	
	$data = array(
		"username" => $_POST['username'],
		"password" => md5($_POST['password']),
		"status" => "0"
	);
	
	$condimanage = "AND";
	$select = $lib -> select($dataname,$data,$condimanage);

	if(!empty($select)){
		session_start();
		
		if($select[0]['type'] == 1){
			$_SESSION['memberType'] = $select[0]['type'];
			$_SESSION['memberId'] = $select[0]['id'];
			header('location:'.$basename);
		}
		
		if($select[0]['type'] == 2){
			$_SESSION['memberType'] = $select[0]['type'];
			$_SESSION['memberId'] = $select[0]['id'];
			header('location:'.$basename);
		}
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
 <link rel="stylesheet" href="<?php echo $assets; ?>adminassets/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $assets; ?>adminassets/dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo $assets; ?>adminassets/plugins/iCheck/square/blue.css">
</head>

<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    My</b>Admin
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign In</p>

    <form name="login" class="mt" method="post" action="login.php">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" name="username" placeholder="Email">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="password" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" name="sublog" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo $assets; ?>adminassets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo $assets; ?>adminassets/bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo $assets; ?>adminassets/plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
