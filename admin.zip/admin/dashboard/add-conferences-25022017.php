<?php
error_reporting(0);
include ("header.php");
$lib = new library;
$hostname = $lib -> hostname();

//print_r($volume);

if (isset($_POST['submit'])) {
	// print_r($_POST);
	// print_r($_FILES);
	
	$file_name = "";
	
	if(isset($_FILES['conference_doc']['name'])) :
		$extentions = array('pdf');

		$filename = $_FILES['conference_doc']['name'];
		$filetype = $_FILES['conference_doc']['type'];
		$fileerror = $_FILES['conference_doc']['error'];
		$filesize = $_FILES['conference_doc']['size'];
		$filetmpname = $_FILES['conference_doc']['tmp_name'];
		
		$namechanger = date('YmdHis');
		
		$dirupload = '../../conference_docs/';
		
		$updload = $lib->fileupload($extentions, $filename, $filetype, $fileerror, $filesize, $filetmpname, $namechanger, $dirupload);
		
		if($updload){
			$file_name = $namechanger.$filename;
		}
	endif;
	
	if($updload){
		$insert = $lib->insert('conferences',array(
			'title' => $_POST['title'],
			'conference_date' => date('Y-m-d',strtotime($_POST['conference_date'])),
			'location' => $_POST['location'],
			'organizer' => $_POST['organizer'],
			'conference_doc' => $file_name,
		));
		
		if($insert){
			$msg = "Congratulations!! Conference details added successfully.";
		}
	} else {
		$msg = "Sorry!! File format is not correct or something went wrong, please try again.";
	}
	
}
?>
<link href="../../adminassets/plugins/datepicker/datepicker3.css" rel="stylesheet" />
<aside class="main-sidebar">
  <?php
	include ("nav.php");
 ?>
</aside>
<div class="content-wrapper">
  <section class="content-header">
    <h1> Add Conferences </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Add Conferences</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-8" style="padding-left:10px">
        <div class="box box-primary">
          <!--<div class="box-header with-border">
            <h3 class="box-title">Add News & Updates</h3>
          </div>-->
          <form enctype="multipart/form-data" method="post" action="">
          <div class="box-body">
		  	<?php if(!empty($msg)) { ?>
            	<p class="text-green"><?php echo $msg; ?></p>
            <?php } ?>
            <div class="row">
              <div class="col-md-6">
                <label>Title</label>
                <input type="text" name="title" class="form-control" required="required" />
              </div>
              <div class="col-md-6">
                <label>Organizer / Venue</label>
                <input type="text" name="organizer" class="form-control" required="required" />
              </div>
              <div class="col-md-4">
                <label>Conference Date</label>
                <input type="text" name="conference_date" class="form-control datepicker" style="border-radius: 0px;" required="required" />
              </div>
              <div class="col-md-12">
                <label>Conference Location</label>
                <textarea name="location" class="form-control" required="true"></textarea>
              </div>
              <div class="col-md-12">
                <label>Conference Document</label>
                <input type="file" name="conference_doc" required="required" />
              </div>
            
              <div class="col-md-12">
              	<input type="submit" name="submit" id="submit" value="Submit" class="btn btn-warning btn-flat" style="margin-top:10px" />
              </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>
<?php
	include ('footer.php');
 ?>
<script language="JavaScript" language="JavaScript" src="../../adminassets/plugins/datepicker/bootstrap-datepicker.js" ></script>

<script>
	$(function() {
		$(".textarea").wysihtml5();
		$(".datepicker").datepicker({
			format: 'mm-dd-yyyy',
			autoclose: true,
		});
	}); 
</script>
<script>
	function check() {
		var title = $("#title");
		var desc = $("#desc");

		if (title.val() == "") {
			title.focus();
			title.addClass('validation');
			return false;
		} else {
			title.removeClass('validation');
		}

		if (desc.val() == "") {
			desc.focus();
			desc.addClass('validation');
			return false;
		} else {
			desc.removeClass('validation');
		}

		return true;
	}
</script>
