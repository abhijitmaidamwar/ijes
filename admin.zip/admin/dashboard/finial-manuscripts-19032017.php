<?php
error_reporting(0);
include('header.php');
$lib = new library;
$hostname = $lib->hostname();
$finialmanuscript = $lib->select('finialmanuscript',array('is_delete' => 0),'','ORDER BY entry DESC');
?>

<aside class="main-sidebar">
  <?php include("nav.php"); ?>
</aside>


<div class="content-wrapper">
  <section class="content-header">
    <h1>Final Manucsripts</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Final Manuscripts</li>
    </ol>
  </section>
  <?php
  if(!empty($_GET['delete'])){
    $paperDetails = $lib->select("finialmanuscript",array("id"=>$_GET['delete']));
    $paperDetails = $paperDetails[0];
    $pagekey = $paperDetails['pagekey'];
    $paperId = $paperDetails['paperId'];

    if(!empty($pagekey) && !empty($paperId)){
      $finalmanuscript_delete = $lib->update("finialmanuscript",$_GET['delete'],array("pstatus"=>0,"is_delete"=>1));
      $samplemanuscript_delete = $lib->update("samplemanuscript",array("pagekey"=>$pagekey,"paperId"=>$paperId),array("status"=>0));
    }


    if($finalmanuscript_delete && $samplemanuscript_delete){
      header("Location: ".$hostname."finial-manuscripts.php");
    }
  }
  ?>
  <!-- Main content -->
  <section class="content">
    <div class="row">	
      <div class="col-md-12" style="padding-left:10px">
        <div class="box box-primary">
          <div id="modal"></div>
            <!--<div class="box-header">
              <h3 class="box-title">News & Updates</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
             <form enctype="multipart/form-data" method="post" onsubmit="return senddata();" id="manuscripts-for-approval">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                  	<th>Sr. No</th>
                    <th>Paper Id</th>
                    <th>Title of Manuscript</th>
                    <th>Name of author</th>
                    <th>Area</th>
                    <th>Date of submission</th>
                    <th style="width: 150px;">Action</th>
                  </tr>
                </thead>
                 <tbody>
                <?php 
					$sr = 1;
					foreach($finialmanuscript as $key => $val) { 
					$datetime = explode(" ",$val['entry']);
					$date = date('d M Y',strtotime($datetime[0]));
					$ftechpaperId = $lib->select("samplemanuscript",array("pagekey" => $val['pagekey']));
					$paperId = $ftechpaperId[0]['paperId'];
					?>
                  <tr>
                  	<td><?php echo $sr++; ?></td>
                   	<td><?php echo $paperId; ?></td>
                    <td><?php echo $val['title']; ?></td>
                    <td><?php echo $val['nameofauthor']; ?></td>
                    <td width="200px"><?php echo $val['area']; ?></td>
                    <td><?php echo $date; ?></td>
			        <td style="text-align: center;">
                    	<a href="finialmanuscript-details.php?id=<?php echo $val['id'];?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Manuscript Details"><i class="fa fa-align-justify"></i></a>
                    	<a href="finial-manuscripts.php?delete=<?php echo $val['id'];?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Manuscript Details"><i class="fa fa-trash"></i></a>
                        <?php if($val['pstatus'] == 1) {?>
                        	<input type="button" name="success" class="btn btn-success btn-flat btn-sm" value="Published" />
                        <?php } ?>
                   </td>
                       
                  </tr>
                <?php } ?>  
                </tbody>
                
              </table>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
      </div>
    </div>
  </section>
</div>
<?php include('footer.php'); ?>
