<?php
ob_start();
class db{
        public $dbhost = 'localhost:3306';
        public $dbuser = 'cybyrywk_app';
        public $dbpass = 'wts()$#@!';
        public $dbname = 'cybyrywk_app';
	
	function __construct()
	{
		$con = mysql_connect($this->dbhost,$this->dbuser,$this->dbpass);
		$db = mysql_select_db($this->dbname,$con);	
	}	
}
?>
