<?php
	session_set_cookie_params(0);
	session_start();
	error_reporting(0);
	// if (!isset($_SESSION['memberId'])){
		// header('location:login.php');
	// }
// 	
	include('lib/library.class.php');
?>