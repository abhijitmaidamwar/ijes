<?php
function get_contect()
{
	list($p,$ext) = explode('.',$_GET['url']);
	$page = $p?$p:'index';
	if(file_exists('pages/'.$page.'.php'))
	{
		include('pages/'.$page.'.php');
	}
	else
	{
		include('pages/404.php');
	}
}

function get_title()
{
	if($_GET['url'])
	{
		list($p,$ext) = explode('.',$_GET['url']);
		$t = str_replace('-',' ',$p);
		$s = ucwords($t) . ' | KRIMS Hospitals';
		return($s); 
	}
	else
	{
		return('Welcome to KRIMS Hospitals');
	}
}
?>