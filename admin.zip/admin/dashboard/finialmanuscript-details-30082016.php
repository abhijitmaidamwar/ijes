<?php 
error_reporting(0);
include('header.php'); 

$lib = new library;
$hostname = $lib->hostname();
$hostmain = $lib->hostmain();

if(isset($_GET['id'])){
	
	$data = array(
			"id" => $_GET['id']
		);
	
		$details = $lib->select('finialmanuscript',$data);
		$details = $details[0];
}

$table = "sentjournals";
$sentjournals = $lib->select($table,array('mId' => $_GET['id']));

$manuscript = $lib->select("finialmanuscript",array('id' => $_GET['id']));
$manuscript = $manuscript[0];

if(isset($_POST['submitvol'])){
	$table = "finialmanuscript";
	$namechanger = date('dmy');
	$_FILES['finalscript']['name'] = str_replace(' ','-',$namechanger.$_FILES['finalscript']['name']);
	
	if(!empty($_FILES['finalscript'])){		
		$src = $_FILES['finalscript']['tmp_name'];
		$dest = '../../finial-docs/finial-pdf/'.$_FILES['finalscript']['name'];
		move_uploaded_file($src,$dest);
	}
	
	$data = array(
		"volume" => $_POST['volume'],
		"number" => $_POST['number'],
		"year" => $_POST['year'],
		"finalscript" => $_FILES['finalscript']['name']
	);
	
	$update = $lib->update($table,$_GET['id'],$data);
	
	if($update){
		
		$to = $manuscript['nameofauthor']." <".$manuscript['email'].">";
				
		$subject = 'Your Final Manuscript Has been Published';
		
		$message = '
		<div style="margin: 0 auto; max-width: 600px; padding: 5px; border-radius: 5px;">
			<div style="float: left; width: 100%; text-align: center; font-size: 22px;">
				<img src="'.$hostmain.'images/logo.png" />
			</div>
			<div style="float: left; width: 100%; text-align: center; font-size: 22px; margin-top: 5px;">
				International Journal of Innovations in Engineering and Science
			</div>
			<div style="clear: both;"></div>
			<hr style="border-color: #3d3e3c;"/>
			<div>
				<p>
					Dear <strong>'.$manuscript['nameofauthor'].' </strong>,
				</p>

				<p>
					Paper Title: <strong>'.$manuscript['title'].'</strong>
				</p>

				<p style="text-align: justify">
					This is to inform you that your paper '.$manuscript['title'].' has been published in vol ('.$_POST['volume'].') No. ('.$_POST['number'].'), <br />
					link for your Final Manuscript: <a href="'.$hostmain.'archives/vol-'.$_POST['volume'].'-no-'.$_POST['number'].'">'.$hostmain.'archives/vol-'.$_POST['volume'].'-no-'.$_POST['number'].'</a>
				</p>
			</div>
			<div style="padding: 10px; background: #3aa7c4; border-radius: 5px; font-size: 14px; text-align: center;">
				For more details please visit <a href="'.$hostmain.'" target="_blank">www.ijies.net</a>
			</div>
		</div>';
		
		$headers   = array();
		$headers[] = 'MIME-Version: 1.0';
		$headers[] = 'Content-type: text/html; charset=iso-8859-1';
		
		// Additional headers
		$headers[] = "From: International Journal of Innovations in Engineering and Science <info@ijies.net>";
		$headers[] = "Reply-To: International Journal of Innovations in Engineering and Science <info@ijies.net>";
		$headers[] = "Subject: {".$subject."}";
		$headers[] = "X-Mailer: PHP/".phpversion();
		
		// Mail it
		$rmail = mail($to, $subject, $message, implode("\r\n", $headers));
		
		header("Location:finialmanuscript-details.php?id=".$_GET['id']."&status=published");
	}
}

?>
  <aside class="main-sidebar">
	<?php include("nav.php"); ?>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Final Manuscript Details
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Final Manuscript</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	
      <div class="row">
      <?php 
	  	if($_GET['status'] == "published"){
	  ?>
      	 <div class="col-md-12">
         	<div class="alert alert-success" style="padding:5px;margin-bottom:6px">
            	Script is successfully finalised to publish!!
            </div>
         </div>
      <?php } ?>
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Final Manuscript Details</a></li>
              <li><a href="#tab_2" data-toggle="tab">Final Script</a></li>
              
              <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
               <div class="form-group">
                    <label> Title : </label>
                    <?php echo $details['title'];?>
                  </div>
				<div class="form-group">
                    <label> Name of author : </label>
                    <?php echo $details['nameofauthor'];?>
                  </div>
              <div class="form-group">
                    <label> Email : </label>
                    <?php echo $details['email'];?>
                  </div>
                  <div class="form-group">
                    <label> Contact : </label>
                    <?php echo $details['contact'];?>
                  </div>
                  <div class="form-group">
                    <label> Co Author : </label>
                    <?php echo $details['coauthor'];?>
                  </div>
                  <div class="form-group">
                    <label> Area : </label>
                    <?php echo $details['area'];?>
                  </div>
                  <div class="form-group">
                    <label> Final Manuscript : </label>
                   <a href="<?php echo $hostmain; ?>finial-docs/finial-manuscripts/<?php echo $details['manuscript'];?>" target="_blank" download><?php echo $details['manuscript'];?></a>
                  </div>
                  <div class="form-group">
                    <label> Copyright form : </label>
                   <a href="<?php echo $hostmain; ?>finial-docs/copyrightform/<?php echo $details['copyrightform'];?>" target="_blank" download><?php echo $details['copyrightform'];?></a>
                  </div>
                  <div class="form-group">
                    <label> Payment Proof : </label>
                   <a href="<?php echo $hostmain; ?>finial-docs/paymentproof/<?php echo $details['paymentproof'];?>" target="_blank" download><?php echo $details['paymentproof'];?></a>
                  </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
              <?php if(empty($manuscript['volume']) && empty($manuscript['number'])) { ?>
              	<form enctype="multipart/form-data" method="post" id="addvolno">
                <div class="row">
                	<div class="col-md-4">
                    	   <label>Enter Volume</label>
                        <input type="number" min="1" name="volume" id="volume" required="required" class="form-control"  />
                    </div>
                </div>    
                 <div class="row">
                    <div class="col-md-4">
                      	<label>Enter Number</label>
                        <input type="number" min="1" name="number" id="number" required="required" class="form-control"  />
                      </div>
                   </div>
                    <div class="row">   
          			<div class="col-md-4">
                    		<label>Select Year:</label>
                            <select name="year" id="year" class="form-control">
                        	<option value="2014">2014</option>
                            <option value="2015">2015</option>
                            <option value="2016">2016</option>
                            <option value="2017">2017</option>
                            <option value="2018">2018</option>
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                        </select>
                    </div>
                   </div>
                    <div class="row"> 
                    <div class="col-md-4">
                    	<label>Upload Final Script to publish</label>
                        <input type="file" name="finalscript" id="finalscript" class="form-control" style="padding:0px" />
                    </div>
                    </div>
                     <div class="row">
                    	<div class="col-md-4" style="padding-top:10px">
                        <input type="submit" name="submitvol" id="submitvol" value="Submit" class="btn btn-warning btn-flat"  />
                       </div> 
                    </div>
                </form>
                <?php } else { ?>
                	<h4>Manucsript is already finalised to publish!</h4>
                <?php } ?>
              </div>
              <!-- /.tab-pane -->
              
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->

        
        <!-- /.col -->
      </div>

    </section>
   
  </div>
<?php include('footer.php'); ?>