<?php
error_reporting(0);
include("header.php");
$lib = new library;
$hostname = $lib->hostname();

if(isset($_POST['submit'])){
	
	$checkdata = array(
		"title" => $_POST['title']
	);
	
	$check = $lib->select('news',$checkdata);
	
	if(empty($check)){
		$data = array(
			"title" => $_POST['title'],
			"details" => $_POST['desc'],
			"alias" => str_replace(' ','-',strtolower($_POST['title']))
		);
	
		$insert = $lib->insert('news',$data);
	}
	
}

if(isset($_POST['update'])){
	
			$data = array(
			"title" => $_POST['title'],
			"details" => $_POST['desc'],
			"alias" => str_replace(' ','-',strtolower($_POST['title']))
		);
		
		$update = $lib->update('news',$_GET['editid'],$data);

	
}

if(isset($_GET['editid'])){
	
	$data = array(
			"id" => $_GET['editid']
		);
	
		$editrow = $lib->select('news',$data);
		$editrow = $editrow[0];
}

?>

<aside class="main-sidebar">
  <?php include("nav.php"); ?>
</aside>
<div class="content-wrapper">
  <section class="content-header">
    <h1> Add News & Updates </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Add news</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-8" style="padding-left:10px">
        <div class="box box-primary">
          <!--<div class="box-header with-border">
            <h3 class="box-title">Add News & Updates</h3>
          </div>-->
          <div class="box-body">
            <?php if(!empty($insert)) { ?>
            <b class="text-green">Added successfully.</b>
            <?php	}  if(!empty($check)) { ?>
            <b class="text-red"> Sorry! Title already exists.</b>
            <?php }  if(!empty($update)) { ?>
            <b class="text-green">Updated successfully.</b>
            <?php	}  ?>
            <form method="post" enctype="multipart/form-data" onsubmit="return check();">
              <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" id="title" class="form-control" placeholder="News Title" value="<?php if(!empty($editrow)){ echo $editrow['title']; }?>" />
                <p class="text-red"><small>*please dont use special characters.</small></p>
              </div>
              <div class="form-group">
                <label>Description</label>
                <textarea class="textarea" name="desc" id="desc" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php if(!empty($editrow)){ echo $editrow['details']; }?>
</textarea>
              </div>
              <div class="form-group pull-right">
                <?php if(empty($editrow)){ ?>
                <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-block btn-flat pull-right" />
                <?php } else { ?>
                <input type="submit" name="update" value="Update" class="btn btn-warning pull-right btn-block btn-flat"  />
                <?php } ?>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php include('footer.php'); ?>
<script>
  $(function () {
    $(".textarea").wysihtml5();
  });
</script>
<script>
	function check(){
		var title = $("#title");
		var desc = $("#desc");
		
		if(title.val() == ""){
			title.focus();
			title.addClass('validation');
			return false;
		}
		else{
			title.removeClass('validation');
		}
		
		if(desc.val() == ""){
			desc.focus();
			desc.addClass('validation');
			return false;
		}
		else{
			desc.removeClass('validation');
		}
		
		return true;
	}
</script>
