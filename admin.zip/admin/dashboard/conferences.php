<?php
error_reporting(0);
include ('header.php');
$lib = new library;
$hostname = $lib -> hostname();
if(isset($_GET['delete']) && $_GET['delete'] != ""){
	$delete = $lib->update('conferences',$_GET['delete'],array('status'=>1));
	if($delete){
		$msg = 'Conference details has been removed successfully.';	
	}
}

?>

<aside class="main-sidebar">
	<?php
	include ("nav.php");
	?>
</aside>

<div class="content-wrapper">
	<section class="content-header">
		<h1>Conferences</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="active">
				Conferences
			</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-12" style="padding-left:10px">
				<div class="box box-primary">
					<div id="modal"></div>
					<!--<div class="box-header">
					<h3 class="box-title">News & Updates</h3>
					</div>-->
					<!-- /.box-header -->
					<div class="box-body">
						<?php if(!empty($msg)) { ?>
			            	<p class="text-green"><?php echo $msg; ?></p>
			            <?php } ?>
						<table id="example1" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th style="width: 50px;">Sr. No</th>
									<th style="width: 200px;">Title</th>
									<th style="width: 70px;">Date</th>
									<th>Location</th>
									<th>Organizer / Venue</th>
									<th>Conference Document</th>
									<th class="hidden"></th>
								</tr>
							</thead>
							<tbody>
								<?php
								$conferences = $lib->select('conferences',array('status'=>0),'','ORDER BY conference_date DESC');
								$sr = 1;
								foreach ($conferences as $key => $conference):
								?>
								<tr>
									<td style="text-align: center;"><?php echo $sr++; ?></td>
									<td><?php echo $conference['title']; ?></td>
									<td style="text-align: center;"><?php echo date('d-m-Y',strtotime($conference['conference_date'])); ?></td>
									<td><?php echo $conference['location']; ?></td>
									<td><?php echo $conference['organizer']; ?></td>
									<td style="text-align: center; width: 150px;"><a href="../../conference_docs/<?php echo $conference['conference_doc']; ?>">Download PDF</td>
									<td style="width: 50px; text-align: center;">
										<a href="?delete=<?php echo $conference['id']; ?>" class="btn btn-danger btn-flat"><i class="fa fa-times"></i></a>
									</td>
								</tr>
								<?php
								endforeach;
								?>
							</tbody>
						</table>
					</div>
					<!-- /.box-body -->
				</div>
			</div>
		</div>
	</section>
</div>
<?php
	include ('footer.php');
?>
