<?php 
error_reporting(0);
include('header.php'); 

$lib = new library;
$hostname = $lib->hostname();
$hostmain = $lib->hostmain();


if(isset($_GET['id'])){
	
	$data = array(
			"id" => $_GET['id']
		);
	
		$details = $lib->select('samplemanuscript',$data);
		$details = $details[0];
//  		print_r($details);
//  		exit;
}

$table = "sentjournals";
$sentjournals = $lib->select($table,array('mId' => $_GET['id']));
//  		print_r($sentjournals);
//  		exit;
$manuscript = $lib->select("samplemanuscript",array('id' => $_GET['id']));
$manuscript = $manuscript[0];

$reviewersApproved = $lib->select("sentjournals",array("mId" => $_GET['id'],"approvalStatus" => 1),"AND");	
$checkcount = count($reviewersApproved);

$finialmanuscript = $lib->select("finialmanuscript",array("pagekey" => $manuscript['pagekey']));

?>
  <aside class="main-sidebar">
	<?php include("nav.php"); ?>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Sample Manuscript Details
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	<?php if($checkcount != 0 && empty($manuscript['pagekey'])) {?>
      <div class="row">
        <div class="col-md-12">
        		<a href="javascript:void(0);" class="alert alert-success col-md-12" style="padding:3px"><b><?php echo $details['nameofauthor']."'s";?></b> manuscript is <b>Approved</b> by reviewer! click here to proceed for final manuscript provision! <input type="button" class="btn bg-orange margin btn-sm" value="send" style="margin:0px;"  onclick="return sendFinialscripform(<?php echo $details['id']; ?>);" /></a>
        </div>
      </div>
     <?php } if(!empty($manuscript['pagekey'])) { ?>
     			<a href="javascript:void(0);" class="alert alert-warning col-md-12" style="padding:3px">The acceptance letter has been sent to the author but final submission of script is remained from author!</a>
     <?php } ?>   
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Manuscript Details</a></li>
              <li><a href="#tab_2" data-toggle="tab">Reviewer's Approval Status</a></li>
              
              <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
               <div class="form-group">
                    <label> Paper Id : </label>
                    <?php echo $details['paperId'];?>
                  </div>
               <div class="form-group">
                    <label> Title : </label>
                    <?php echo $details['title'];?>
                  </div>
				<div class="form-group">
                    <label> Name of author : </label>
                    <?php echo $details['nameofauthor'];?>
                  </div>
              <div class="form-group">
                    <label> Email : </label>
                    <?php echo $details['email'];?>
                  </div>
                  <div class="form-group">
                    <label> Contact : </label>
                    <?php echo $details['contact'];?>
                  </div>
                  <div class="form-group">
                    <label> Co Author : </label>
                    <?php echo $details['coauthor'];?>
                  </div>
                  <div class="form-group">
                    <label> Area : </label>
                    <?php echo $details['area'];?>
                  </div>
                  <div class="form-group">
                    <label> Sample Manuscript : </label>
                  <a href="<?php echo $hostmain; ?>sample-manuscripts/<?php echo $details['manuscript'];?>" target="_blank" download><?php echo $details['manuscript'];?></a>
                  </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                 <?php if(!empty($sentjournals)){ ?>
              <table class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                    	<thead>
                        	<tr>
                            	<th>Sr. No</th>
                                <th>Reviewer's Name</th>
                                <th>Approval Status</th>
                            </tr>
                        </thead>
                        <tbody>
                    
                <?php 
					$sr = 1;
					foreach($sentjournals as $key => $val) { 
						$reviewers = $lib->select('reviewers',array('id' => $val['rId']));
						
				?>
                	    	<tr>
                            	<td><?php echo $sr++; ?></td>
                                <td><?php echo $reviewers[0]['name']; ?></td>
                                <td>
									<?php if($val['approvalStatus'] == 0) { ?>
                                    	<div class="btn btn-warning btn-sm">Pending</div>
                                    <?php } ?>
									<?php if($val['approvalStatus'] == 1) { ?>
                                    	<div class="btn btn-success btn-sm">Approved</div>
                                    <?php } ?>
									<?php if($val['approvalStatus'] == 2) { ?>
                                    	<div class="btn btn-danger btn-sm">Rejected</div>
                                    <?php } ?>
                                </td>
                            </tr>
                <?php } ?>
                
                        </tbody>
                    </table>
                    
                    <?php } else{ ?>
                    <h4 style="color:#FF0000">No results found!</h4>
                    <?php } ?>
              </div>
              <!-- /.tab-pane -->
              
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->

        
        <!-- /.col -->
      </div>

    </section>
   
  </div>
<?php include('footer.php'); ?>