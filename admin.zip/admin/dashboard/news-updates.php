<?php
error_reporting(0);
include("header.php");
$lib = new library;
$hostname = $lib->hostname();

$news = $lib->select('news');

if(isset($_GET['getE'])){
	
	$id = $_GET['getE'];
	$data = array(
		"status" => 0
	);

	$enable = $lib->update('news',$id,$data);	
	
	header("Location:news-updates.php");
	
}

if(isset($_GET['getD'])){
	
	$id = $_GET['getD'];
	$data = array(
		"status" => 1
	);

	$disable = $lib->update('news',$id,$data);	
	header("Location:news-updates.php");
	
}

?>
<aside class="main-sidebar">
  <?php include("nav.php"); ?>
</aside>


<div class="content-wrapper">
  <section class="content-header">
    <h1>News & Updates </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">News & Updates</li>
    </ol>
  </section>
  
  <!-- Main content -->
  <section class="content">
    <div class="row">
    	
		<?php if(!empty($disable)) { ?>
        <div class="col-sm-12">
          <div class="alert alert-danger" style="padding:5px"><b>Done!</b> Your news is <b>disabled</b> successfully.</div>
        </div>
        <?php } ?>
        
        <?php if(!empty($enable)) { ?>
        <div class="col-sm-12">
           <div class="alert alert-success" style="padding:5px"><b>Done!</b> Your news is <b>enabled</b> successfully.</div>
        </div>
        <?php } ?>
        
      <div class="col-md-12" style="padding-left:10px">
        <div class="box box-primary">
            <!--<div class="box-header">
              <h3 class="box-title">News & Updates</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                  	<th>Sr. No</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th class="hidden"></th>
                    <th class="hidden"></th>
                  </tr>
                </thead>
                 <tbody>
                <?php 
					$sr = 1;
					foreach($news as $key => $val) { ?>
                  <tr>
                  	<td><?php echo $sr++; ?></td>
                    <td><?php echo $val['title']; ?></td>
                    <td><?php echo $val['details']; ?></td>
                    <td>
                    <?php if($val['status'] == 0) { ?>
                    		<a href="news-updates.php?getD=<?php echo $val['id'];?>" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Click to disable?"><i class="fa fa-check-square"></i></a>
                    <?php } if($val['status'] == 1) { ?>
                    		<a href="news-updates.php?getE=<?php echo $val['id'];?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Click to enable?"><i class="fa fa-close"></i></a>
                    <?php } ?>
                    </td>
                    <td>
                    	<a href="add-news-updates.php?editid=<?php echo $val['id'];?>" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Click to update?"><i class="fa fa-pencil"></i></a>
                    </td>
                  </tr>
                <?php } ?>  
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
      </div>
    </div>
  </section>
</div>
<?php include('footer.php'); ?>
<script>
  $(function () {
    $(".textarea").wysihtml5();
  });
</script>

<script>
	function check(){
		var title = $("#title");
		var desc = $("#desc");
		
		if(title.val() == ""){
			title.focus();
			title.addClass('validation');
			return false;
		}
		else{
			title.removeClass('validation');
		}
		
		if(desc.val() == ""){
			desc.focus();
			desc.addClass('validation');
			return false;
		}
		else{
			desc.removeClass('validation');
		}
		
		return true;
	}
</script>