<?php error_reporting(1);
include ('header.php');
$lib = new library;
$hostname = $lib -> hostname();

if(isset($_POST['submit']) == 'Add Category' || $_POST['submit'] == 'Add Category'){
	$categoryName=$_POST['categoryName'];
	
	$insert = mysql_query("insert into boardcategory (categoryName) VALUES ('".$categoryName."')");
	if($insert){
?>
<script>window.alert("Category added Successfully");</script>
<?php }else { ?>
<script>window.alert("OOps Something went wrong.. please try again");</script>
<?php } } 

if (isset($_GET['action']) == 'delete') {
	$del = mysql_query("delete from boardmembers where id='" . $_GET['id'] . "'");
	header("Location:board-member-list");
}
 
?>


<aside class="main-sidebar">
	<?php
	include ("nav.php");
	?>
</aside>

<div class="content-wrapper" style="min-height: 600px;">
	<section class="content-header">
		<h1>Editorial Board List</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="active">
				Editorial Board Category
			</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content col-md-12">
		<!-- section start-->
		<!-- SELECT2 EXAMPLE -->
		<div class="box box-default">
			<!-- box start start-->
			<div class="box-header with-border">
				<h3 class="box-title">Category List</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse">
						<i class="fa fa-minus"></i>
					</button>
					<button type="button" class="btn btn-box-tool" data-widget="remove">
						<i class="fa fa-remove"></i>
					</button>
				</div>
			</div>
			<!-- /.box-header -->

			<div class="box-body" style="text-transform: capitalize;">
				<div class="col-md-12  border-1px padding-10">
					<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">

						<div class="col-sm-12">
							<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
								<div class="row">
									<div class="col-sm-12">
										<table class="table  table-bordered table-striped dataTable no-footer" id="example1" role="grid" aria-describedby="example1_info">
											<thead>
												<tr role="row">
													<th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 90px;" aria-label="Name: activate to sort column descending" aria-sort="ascending"> ID</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Member Name</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Board Category</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Profession</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Designation</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Contact No.</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Email</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Sequence</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Action</th>
													

												</tr>
											</thead>
											<tbody>
													<?php $query = mysql_query("select * from boardmembers order by sequence");
														  while ($data = mysql_fetch_array($query)) {
													?>
												<tr role="row" class="odd">
													<td class="sorting_1"><?php echo $data['id']; ?></td>
													<td><?php echo $data['memberName']; ?></td>
													<td><?php $queryCategory = mysql_query("select * from boardcategory");
													  while ($category = mysql_fetch_array($queryCategory)) {if($data['category'] == $category['id']){ echo $category['categoryName'];} }?></td>
													<td><?php echo $data['profession']; ?></td>
													<td><?php echo $data['designation']; ?></td>
													<td><?php echo $data['phone']; ?></td>
													<td><?php echo $data['email']; ?></td>
													<td><?php echo $data['sequence']; ?></td>
													<td>
														<a href="board-member-edit?id=<?php echo $data['id']; ?>" class="btn btn-sm btn-warning" title="Edit Member"><i class="fa fa-edit"></i></a>
														<button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal-<?php echo $data['id']; ?>"><i class="fa fa-close"></i></button>
														<!-- <a href="board-member-list?action=delete&&id=<?php echo $data['id']; ?>" class="btn btn-sm btn-danger" title="Delete Member"><i class="fa fa-close"></i></a> -->
													</td>
													
													<div class="modal fade" id="myModal-<?php echo $data['id']; ?>" role="dialog">
													    <div class="modal-dialog modal-sm">
													      <div class="modal-content">
													        <div class="modal-header">
													          <button type="button" class="close" data-dismiss="modal">&times;</button>
													          <h4 class="modal-title">Confirmation</h4>
													        </div>
													        <div class="modal-body">
													          <p>The Board member Named <strong><?php echo $data['memberName']; ?> </strong> will be deleted permanently. <br /><br /> Are you sure?</p>
													        </div>
													        <div class="modal-footer">
													          <a href="board-member-list?action=delete&&id=<?php echo $data['id']; ?>" class="btn btn-sm btn-danger" title="Delete Member">Delete</a>
													          <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
													        </div>
													      </div>
													   </div>
													</div>
													
													
												</tr>
												<?php }?>
											</tbody>
										</table>
									</div>
								</div>

							</div>
						</div>

					</div>
				</div>

			</div>

		</div>
	</section>
</div>
<?php
include ('footer.php');
?>