<?php
error_reporting(0);
include("header.php");
$lib = new library;
$hostname = $lib->hostname();


//print_r($volume);

if(isset($_POST['publish'])){
	
	$updatepstatus = mysql_query("UPDATE finialmanuscript SET pstatus=1 WHERE volume='".$_POST['volume']."' and number='".$_POST['number']."' and year='".$_POST['year']."'");
	
	if($updatepstatus){
		$update = mysql_query("UPDATE finialmanuscript SET pstatus=0 WHERE volume != '".$_POST['volume']."' OR number != '".$_POST['number']."' OR year != '".$_POST['year']."'");
		if($update){	
				$msg = "Published Successfully!";
			}	
	}else{
		$msg = "Somthing went wrong";
	}
	
	
}


?>

<aside class="main-sidebar">
  <?php include("nav.php"); ?>
</aside>
<div class="content-wrapper">
  <section class="content-header">
    <h1> Current Issues </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Current Issues</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-8" style="padding-left:10px">
        <div class="box box-primary">
          <!--<div class="box-header with-border">
            <h3 class="box-title">Add News & Updates</h3>
          </div>-->
          <form enctype="multipart/form-data" method="post">
          <div class="box-body">
		  	<?php if(!empty($msg)) { ?>
            	<p class="text-green"><?php echo $msg; ?></p>
            <?php } ?>
            <div class="row">
              <div class="col-md-4">
                <label>Select Volume</label>
                <select name="volume" id="volume" class="form-control" required="required">
                <option value="">-Select-</option>
                <?php $sql = mysql_query("SELECT DISTINCT volume FROM finialmanuscript");
					while($row = mysql_fetch_assoc($sql)){
					if($row['volume'] != 0){
					 ?>
                  <option value="<?php echo $row['volume']; ?>"><?php echo $row['volume']; ?></option>
                <?php } }?>  
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                <label>Select Number </label>
                <select name="number" id="number" class="form-control"  required="required">
                <option value="">-Select-</option>
                <?php $sql = mysql_query("SELECT DISTINCT number FROM finialmanuscript");
					while($row = mysql_fetch_assoc($sql)){
					if($row['number'] != 0){
					 ?>
                  <option value="<?php echo $row['number']; ?>"><?php echo $row['number']; ?></option>
                <?php } } ?>  
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                <label>Select Year</label>
                <select name="year" id="year" class="form-control" required="required">
                <option value="">-Select-</option>
                <?php $sql = mysql_query("SELECT DISTINCT year FROM finialmanuscript");
					while($row = mysql_fetch_assoc($sql)){
					if($row['year'] != ""){
					 ?>
                  <option value="<?php echo $row['year']; ?>"><?php echo $row['year']; ?></option>
                <?php } } ?>  
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
              	<input type="submit" name="publish" id="publish" value="Publish" class="btn btn-warning btn-flat" style="margin-top:10px" />
              </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>
<?php include('footer.php'); ?>
<script>
  $(function () {
    $(".textarea").wysihtml5();
  });
</script>
<script>
	function check(){
		var title = $("#title");
		var desc = $("#desc");
		
		if(title.val() == ""){
			title.focus();
			title.addClass('validation');
			return false;
		}
		else{
			title.removeClass('validation');
		}
		
		if(desc.val() == ""){
			desc.focus();
			desc.addClass('validation');
			return false;
		}
		else{
			desc.removeClass('validation');
		}
		
		return true;
	}
</script>
