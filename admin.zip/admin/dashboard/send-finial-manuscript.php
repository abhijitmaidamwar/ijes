<?php
error_reporting(0);
include('lib/library.class.php');

$lib = new library;
$hostmain = $lib->hostmain();
 
if(!empty($_POST['mId'])){

	$manuscriptDetails = $lib->select('samplemanuscript',array("id" => $_POST['mId']));  
	$manuscript = $manuscriptDetails[0];
	
	$pagekey = sha1($manuscript['id']);
	$updatekey = $lib->update('samplemanuscript',$manuscript['id'],array("pagekey" => $pagekey));
	
	if($updatekey) {
		$frtckey = $lib->select('samplemanuscript',array("pagekey" => $pagekey));
		
		$to  = $manuscript['nameofauthor'].' <'.$manuscript['email'].'>';
		
		$subject = 'Hello '.$manuscript['nameofauthor'].'! Please upload your final manuscript | '.$frtckey[0]['paperId'].'';
		
		$message = '
				<div style="margin: 0 auto; max-width: 600px; padding: 5px; border-radius:5px;">
			<div style="float: left; width: 100%; text-align: center; font-size: 22px;">
				<img src="http://ijies.net/images/logo.png" />
			</div>
			<div style="float: left; width: 100%; text-align: center; font-size: 22px; margin-top: 5px;">
				International Journal of Innovations in Engineering and Science
			</div>
			<div style="clear: both;"></div>
			<hr style="border-color: #3d3e3c;"/>
			
				<h3 style="text-align: center;"> Manuscript Acceptance </h3>
			
			<div>
				<p>
					Dear <strong>'.$manuscript['nameofauthor'].'</strong>,
				</p>

				<p>
					Paper Title: <strong>'.$manuscript['title'].'</strong>
				</p>
                
                <p>
					Paper Id: <strong>'.$frtckey[0]['paperId'].'</strong>
				</p>

				<p style="text-align: justify">
					This is to inform you that your paper title above has been reviewed from number of reviewers. After the remarks of reviewers pannel, editorial board  accepted your paper for publication in upcoming issue. You are kindly requested to pay the required processing fees using Debit card, Credit Card ,Internet banking through online payment or to the following account by means of NEFT / RTGS/ by CASH.  Kindly submit proof payment made and agreement copy though final submission online.
				</p>
				<p>
					Account No: 50336729916
					<br />
					Account Holder: Innovative scientific publication
					<br />
					IFSC Code: ALLA0212639
					<br />
					MICR Code: 440010010
					<br />
				</p>

			</div>
			<h4 style="text-align: center">Instructions to be followed for Final Manuscript Submission</h4>
			<ol>
				<li>
					Please download the copyright form, fill it and upload it while uploading the final manuscript. <a href="http://www.ijies.net/assets/templates/ijies-copyright-form.pdf">Click here to download Copyright Form.</a>
				</li>
				<li>
					Please upload the payment proof. For Payment details please <a href="http://www.ijies.net/processing-charges"> Click Here</a> or visit <a href="http://www.ijies.net/"> www.ijies.net</a>
				</li>
				<li>
					To upload your Manuscript Please click on following link and follow as instructed.
					<br />
				<a href="http://ijies.net/final-submission/'.$pagekey.'">http://ijies.net/final-submission/'.$pagekey.'</a>
				</li>
			</ol>
			<div style=" padding: 5px; text-align: center; border-radius: 5px; margin-bottom:5px; background: #f37079; ">
				Please prepare the Copyright form and Payment Proof before uploading Final Manuscript.
			</div>
			<div style="padding: 10px; background: #3aa7c4; border-radius: 5px; font-size: 14px; text-align: center;">
				For more details please visit <a href="http://www.ijies.net/" target="_blank">www.ijies.net</a>
			</div>
		</div>			';
		
			$headers   = array();
			$headers[] = 'MIME-Version: 1.0';
			$headers[] = 'Content-type: text/html; charset=iso-8859-1';
			
			// Additional headers
			$headers[] = "From: International Journal of Innovations in Engineering and Science <donotreply@ijies.net>";
			$headers[] = "Reply-To: International Journal of Innovations in Engineering and Science <info@ijies.net>";
			//$headers[] = "Subject: {".$subject."}";
			//$headers[] = "X-Mailer: PHP/".phpversion();
			
			// Mail it 
			$mail = mail($to, $subject, $message, implode("\r\n", $headers));
			
			if($mail){
				echo "Finial manuscript link has been sent to author.";
			}else{
				echo "Something went wrong! Please try again - Mail.";
			}
	}else{
				echo "Something went wrong! Please try again - Page Key.";
			}
}else{
				echo "Something went wrong! Please try again - Post";
			}

?>