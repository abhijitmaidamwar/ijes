<?php error_reporting(1);
include ('header.php');
$lib = new library;
$hostname = $lib -> hostname();

if(isset($_POST['submit']) == 'Updtate Member' || $_POST['submit'] == 'Update Member'){
	$Name=$_POST['name'];
	$category =$_POST['category'];
	$profession =$_POST['profession'];
	$designation =$_POST['designation'];
	$phone =$_POST['phone'];
	$email =$_POST['email'];
	$sequence =$_POST['sequence'];
	
	$update = mysql_query("update boardmembers set  memberName = '".$Name."', category =  '".$category."', profession = '".$profession."', designation='".$designation."',  phone='".$phone."', email='".$email."', sequence='".$sequence."' where id ='".$_GET['id']."' ");
	if($update){
?>
<script>
	window.alert("Member added Successfully");
	window.location.href = 'board-member-list.php';
 </script>
<?php }else { ?>
<script>window.alert("OOps Something went wrong.. please try again");</script>
<?php } } ?>

<aside class="main-sidebar">
	<?php
	include ("nav.php");
	?>
</aside>

<div class="content-wrapper">
	<section class="content-header">
		<h1>Editorial Category</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="active">
				Editorial Category
			</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-6" style="padding-left:10px">
				<div class="box box-primary">
					<div id="modal"></div>
					<!--<div class="box-header">
					<h3 class="box-title">News & Updates</h3>
					</div>-->
					<!-- /.box-header -->

					<div class="box box-info col-md-6">
						<div class="box-header ">
							<h3 class="box-title">Editorial Category</h3>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<?php $queryMember = mysql_query("select * from boardmembers where id =  '".$_GET['id']."'");
							 while ($member = mysql_fetch_array($queryMember)) {
						?>

						<form class="form-horizontal" method="post" target="" enctype="multipart/form-data">
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Board Member Name</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Member Name" type="text" name="name" value="<?php echo $member['memberName']; ?>" required="">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Profession</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Profession" type="text" name="profession" value="<?php echo $member['profession']; ?>" required="">
									</div>
								</div>
							</div>
							
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Designation in IJIES</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Designation in IJIES" type="text" name="designation" value="<?php echo $member['designation']; ?>">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group ">
									<label for="inputPassword3" class="col-sm-4 control-label"> Board Category</label>
									<div class="col-sm-6">
									<select class="form-control" name="category">
										<?php $query = mysql_query("select * from boardcategory");
											  while ($data = mysql_fetch_array($query)) {
										?>
										<option  value="<?php echo $data['id'] ?>" <?php
										if ($data['id'] == $member['category']) {echo "selected='selected'";
										}
 ?>><?php echo $data['id']." - ". $data['categoryName'] ?></option>
										<?php } ?>
									</select>
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Mobile No. / Phone No. </label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Contact Number" type="text" name="phone" value="<?php echo $member['phone']; ?>">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Email Id</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Email Id" type="text" name="email" value="<?php echo $member['email']; ?>">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Sequence</label>
									<div class="col-sm-6">
										<input class="form-control"  placeholder="sequence number" type="text" name="sequence" value="<?php echo $member['sequence']; ?>">
									</div>
								</div>
							</div>
							<!-- /.box-body -->
							<div class="box-footer">
								<input type="submit" name="submit" value="Update Member" class="btn btn-info pull-left" />
							</div>
							<!-- /.box-footer -->
						</form>
						<?php } ?>
					</div>
					<!-- /.box-body -->
				</div>
			</div>

		</div>
	</section>
	
</div>
<?php
include ('footer.php');
?>