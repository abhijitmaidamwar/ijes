<?php
error_reporting(0);
session_start();
include('lib/library.class.php');
$lib = new library;
$hostname = $lib->hostname();
$hostmain = $lib->hostmain();
$reviewer = $lib->select('reviewers');

	if(!empty($_POST['mId'])){
		// $_SESSION['mId'] = $_POST['mId'];
   // print_r($_POST['reviewers']);
		?>


        <!-- Modal -->
        <form enctype="multipart/form-data" method="post" action="" onsubmit="return submitdata();" id="reviewer">
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        	<input type="hidden" name="mId" value="<?php echo $_POST['mId']; ?>" />
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Select Reviewers</h4>
                    </div>
                    <div>
                        <?php foreach($reviewer as $key => $val) {
						 ?>
                        	<div class="col-md-4" style="padding-bottom:7px">
                    			<input type="checkbox" name="reviewers[]"  id="reviewers:<?php echo $val['id']; ?>" value="<?php echo $val['id']; ?>">
            					<label for="reviewers:<?php echo $val['id']; ?>" style="padding-left:5px; font-size: 12px;"><?php echo $val['name']; ?></label>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="sendforapproval" id="sendforapproval"  class="btn btn-primary">Send</button>
                    </div>
                        <div id="enq" style="padding:5px; margin-top:5px"></div>
                         <div id="msg" style="padding:5px; margin-top:5px"></div>
                </div>
            </div>
        </div>
        </form>
<?php
		
	}
	if(!empty($_POST['reviewers'])){
		// echo "<pre>";
		 //print_r($_POST['reviewers']);
		// echo "</pre>";
		foreach($_POST['reviewers'] as $rkey => $rval){
			// echo "<pre>";
// 			print_r($rval);
			// echo "</pre>";
			$journal = $lib->select('samplemanuscript',array("id" => $_POST['mId']));
			//print_r($journal);
			
			$fetchreviewer = $lib->select("reviewers",array("id" => $rval));

			$checkdata = array(
				'rId' => $rval,
				'mId' => $_POST['mId']
			);
			
			$check = $lib->select('sentjournals',$checkdata,' AND '); 
			
			if(empty($check)){
				$data = array(
					'rId' => $rval,
					'mId' => $_POST['mId'],
					'approvalStatus' => 0,
					'status' => 0
				); 
				
				$insertsentjournals = $lib->insert('sentjournals',$data); 
				
				if($insertsentjournals){
					$to = $fetchreviewer[0]['name']." <".$fetchreviewer[0]['email'].">";
					$subject = "You have new journal for review | ".$journal[0]['paperId']."";
					$message = '
					<div style="color: #3d3e3c; font-size: 13px;">
						<div class="container" style="margin: 0 auto; max-width: 600px; padding: 5px; border-radius: 5px;">
							<div class="logo" style="float: left; width: 100%; text-align: center; font-size: 22px;">
								<img src="'.$hostmain.'images/logo.png" />
							</div>
							<div class="logo" style="float: left; width: 100%; text-align: center; font-size: 22px;">
								International Journal of Innovations in Engineering and Science
							</div>
							<div class="clear" style="clear: both;"></div>
							<hr style="border-color: #3d3e3c;" />
							<div class="heading" style="border-radius: 5px; font-size: 14px; text-align: center;"><h3> Manuscript For Approval </h3></div>
								<div class="parent-div" style="width: 100%;">
									<h4>Dear  '.$fetchreviewer[0]['name'].',</h4>
									<p style="text-align: justify;">You have journal for review. Please login to your reviewer panel.</p>
									<p style="text-align: justify;">To access your panel please click on following link or paste it to browsers address bar </p>
									<a href="'.$hostmain.'reviewer/" target="_blank">'.$hostmain.'reviewer/</a>
									<p style="text-align: justify;"><b>Note:</b> Please use your email id as Username and Password provided by administrator of IJIES. If any query, please contact us or write us to info@ijies.net</p>
								</div>
							  <div class="footer" style="padding: 10px; background: #3aa7c4; border-radius: 5px; font-size: 14px; text-align: center;">
									For more details please visit <a style="text-decoration: none; color:#3d3e3c;" href="'.$hostmain.'" target="_blank">www.ijies.net</a>
							</div>
						</div>
					</div>
					';
					
					$headers   = array();
					$headers[] = 'MIME-Version: 1.0';
					$headers[] = 'Content-type: text/html; charset=iso-8859-1';
					
					// Additional headers
					$headers[] = "From: International Journal of Innovations in Engineering and Science <donotreply@ijies.net>";
					$headers[] = "Reply-To: International Journal of Innovations in Engineering and Science <info@ijies.net>";
					$headers[] = "Subject: {".$subject."}";
					$headers[] = "X-Mailer: PHP/".phpversion();
					
					// Mail it
					$mail = mail($to, $subject, $message, implode("\r\n", $headers));
                    // var_dump($mail);
                    // exit;
                    // echo "dasdas/n";
				}
			} else{
				$rfetchdata = array('id' => $rval);
				$rselect = $lib->select('reviewers',$rfetchdata);
				$fetchdata = array('id' => $_POST['mId']);
				$select = $lib->select('samplemanuscript',$fetchdata);
				echo "<div class='alert alert-danger' style='padding:5px;margin:0px'>".$select[0]['nameofauthor']."'s manuscript is already sent to ".$rselect[0]['name']."</div>";
			}	
		}
		if($insertsentjournals){		
			$fetchdata = array('id' => $_POST['mId']);
			$select = $lib->select('samplemanuscript',$fetchdata);
			echo "<div class='alert alert-success' style='padding:5px;margin:0px'>".$select[0]['nameofauthor']."'s manuscript is sent to selected reviewers successfully..</div>";
		}
		else{
			echo "<div class='alert alert-danger'> Something went wrong. Please try again for ".$select[0]['nameofauthor']."</div>";
		}
}

?>        
<script type="text/javascript">
      $('#myModal').modal('show');
</script>
<script>
	function submitdata(){
		$("#sendforapproval").html("<div class='fa fa-refresh fa-spin disabled'></div>");
		var datastring = new FormData($("#reviewer")[0]);
		
			var retVal = confirm("Are you sure?");
               if( retVal == true ){
                  $.ajax({
					type:'POST',
					url:'<?php echo $hostname; ?>process-data.php',
					processData: false,
    				contentType: false,
					data: datastring,
					success:function(result){
						$("#sendforapproval").html("Submit");
							$('#msg').html(result);
							$("#reviewer")[0].reset();
						
					},
                    error: function(XMLHttpRequest, textStatus, errorThrown) { 
                        alert("Status: " + textStatus); alert("Error: " + errorThrown); 
                    } 
				});
				return false;
               }
				return false;
	}
</script>