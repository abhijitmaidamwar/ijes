<?php
error_reporting(0);
include('header.php');
$lib = new library;
$hostname = $lib->hostname();
$samplemanuscript = $lib->select('samplemanuscript','','','ORDER BY entry DESC');

if(isset($_GET['getE'])){
	
	$id = $_GET['getE'];
	$data = array(
		"status" => 1
	);

	$enable = $lib->update('samplemanuscript',$id,$data);	
	header('Location:sample-manuscripts.php');
}

if(isset($_GET['getD'])){
	
	$id = $_GET['getD'];
	$data = array(
		"status" => 0
	);

	$disable = $lib->update('samplemanuscript',$id,$data);	
	header('Location:sample-manuscripts.php');
	
}

?>

<aside class="main-sidebar">
  <?php include("nav.php"); ?>
</aside>


<div class="content-wrapper">
  <section class="content-header">
    <h1>Sample Manuscript</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Sample Manuscript</li>
    </ol>
  </section>
  
  <!-- Main content -->
  <section class="content">
    <div class="row">
    	
		<?php if(!empty($disable)) { ?>
        <div class="col-sm-12">
          <div class="alert alert-danger" style="padding:5px"><b>Done!</b> Reviewer is <b>disabled</b> successfully.</div>
        </div>
        <?php } ?>
        
        <?php if(!empty($enable)) { ?>
        <div class="col-sm-12">
           <div class="alert alert-success" style="padding:5px"><b>Done!</b> Reviewer is <b>enabled</b> successfully.</div>
        </div>
        <?php } ?>
        
      <div class="col-md-12" style="padding-left:10px">
        <div class="box box-primary">
          <div id="modal"></div>
            <!--<div class="box-header">
              <h3 class="box-title">News & Updates</h3>
            </div>-->
            <!-- /.box-header -->
            <div class="box-body">
             <form enctype="multipart/form-data" method="post" onsubmit="return senddata();" id="manuscripts-for-approval">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                  	<th>Sr. No</th>
                    <th>Paper Id</th>
                    <th>Title of Manuscript</th>
                    <th>Name of author</th>
                    <th>Area</th>
                    <th>Date of submission</th>
                    <th>Action</th>
                  </tr>
                </thead>
                 <tbody>
                <?php 
					$sr = 1;
					foreach($samplemanuscript as $key => $val) { 
					$setjournals = $lib->select("sentjournals",array("mId" => $val['id'],"approvalStatus" => 1),"AND");					
					$approvalcount = count($setjournals);
					$datetime = explode(" ",$val['entry']);
					$date = date('d M Y',strtotime($datetime[0]));
					?>
                  <tr>
                  	<td><?php echo $sr++; ?></td>
                   	<td><?php echo $val['paperId']; ?></td>
                    <td><?php echo $val['title']; ?></td>
                    <td><?php echo $val['nameofauthor']; ?></td>
                    <td width="200px"><?php echo $val['area']; ?></td>
                    <td><?php echo $date; ?></td>
			        <td width="160px">
                    	<a href="samplemanuscript-details.php?id=<?php echo $val['id'];?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Manuscript Details"><i class="fa fa-align-justify"></i></a>
                      <?php  if($approvalcount == 0) {?>
                        <a href="javascript:void(0);" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Click to forward to reviewers!" onclick="return senddata('<?php echo $val['id'];?>');"><i class="fa fa-mail-forward"></i></a>
                       <?php } ?>
                      <?php 
						 if($approvalcount >= 1) { ?>
                        <a href="javascript:void(0);" class="btn bg-olive btn-flat margin btn-xs" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?php echo $val['title']; ?> is approved!">Approved</a>
                     <?php } ?>
                   </td>
                       
                  </tr>
                <?php } ?>  
                </tbody>
                
              </table>
              </form>
            </div>
            <!-- /.box-body -->
          </div>
      </div>
    </div>
  </section>
</div>
<?php include('footer.php'); ?>
