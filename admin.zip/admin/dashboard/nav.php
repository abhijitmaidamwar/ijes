<section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo $assets; ?>adminassets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>IJIES</p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- search form (Optional) -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
        <li class="header">HEADER</li>
        <!-- Optionally, you can add icons to the links -->
        <li <?php if($filename == 'dashboard'){ ?>class="active" <?php } ?>><a href="<?php echo $hostname; ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        
        <li class="treeview  <?php if(in_array($filename,array('add-news-updates','news-updates'))){ echo 'active'; }?>">
          <a href="#"><i class="fa fa-files-o"></i> <span>News Manager</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?php if($filename == 'add-news-updates'){ ?>class="active" <?php } ?>><a href="add-news-updates.php"><i class="fa fa-circle-o"></i>Add News & Updates</a></li>
            <li <?php if($filename == 'news-updates'){ ?>class="active" <?php } ?>><a href="news-updates.php"><i class="fa fa-circle-o"></i>News & Updates</a></li>
          </ul>
        </li>
        
        <li class="treeview  <?php if(in_array($filename,array('add-reviewer','reviewers'))){ echo 'active'; }?>">
          <a href="#"><i class="fa fa-users"></i> <span>Reviewer's Manager</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?php if($filename == 'add-reviewer'){ ?>class="active" <?php } ?>><a href="add-reviewer.php"><i class="fa fa-circle-o"></i>Add Reviewers</a></li>
            <li <?php if($filename == 'reviewers'){ ?>class="active" <?php } ?>><a href="reviewers.php"><i class="fa fa-circle-o"></i>Reviewers</a></li>
          </ul>
        </li>
        
        <li class="treeview  <?php if(in_array($filename,array('sample-manuscripts','finial-manuscripts','samplemanuscript-details','finialmanuscript-details'))){ echo 'active'; }?>">
          <a href="#"><i class="fa fa-edit"></i> <span>Manuscripts Manager</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?php if($filename == 'sample-manuscripts'){ ?>class="active" <?php } ?>><a href="sample-manuscripts.php"><i class="fa fa-circle-o"></i>Sample Manuscripts</a></li>
            <li <?php if($filename == 'final-manuscripts'){ ?>class="active" <?php } ?>><a href="finial-manuscripts.php"><i class="fa fa-circle-o"></i>Final Manuscripts</a></li>
          </ul>
        </li>
        
        <li <?php if($filename == 'current-issues'){ ?>class="active" <?php } ?>><a href="<?php echo $hostname; ?>current-issues.php"><i class="fa fa-dashboard"></i> <span>Current Issues</span></a></li> 
        <li class="treeview  <?php if(in_array($filename,array('add-conferences','conferences'))){ echo 'active'; }?>"> 
        	<a href="#"><i class="fa fa-star"></i> <span>Conference Manager</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
        	  <ul class="treeview-menu">
        	  	 <li <?php if($filename == 'add-conferences'){ ?>class="active" <?php } ?>><a href="add-conferences.php"><i class="fa fa-plus"></i>Add Conferences</a></li>
        	  	             <li <?php if($filename == 'conferences'){ ?>class="active" <?php } ?>><a href="conferences.php"><i class="fa fa-list"></i>Conferences</a></li>  
              </ul> 
        </li>
        <li <?php if($filename == 'call-for-paper'){ ?>class="active" <?php } ?>><a href="<?php echo $hostname; ?>call-for-paper.php"><i class="fa fa-file"></i> <span>Call for Paper</span></a></li>  	                            
     	
     	<li class="treeview  <?php if(in_array($filename,array('editorial-category','board-member-add','board-member-list'))){ echo 'active'; }?>"> 
        	<a href="#"><i class="fa fa-user"></i> <span>Board Manager</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
        	  <ul class="treeview-menu">
        	  	 <li <?php if($filename == 'add-conferences'){ ?>class="active" <?php } ?>><a href="editorial-category"><i class="fa fa-plus"></i>Category Manager</a></li>
        	  	 <li <?php if($filename == 'board-member-add'){ ?>class="active" <?php } ?>><a href="board-member-add.php"><i class="fa fa-plus"></i>Add Board Members</a></li>
        	  	 <li <?php if($filename == 'board-member-list'){ ?>class="active" <?php } ?>><a href="board-member-list.php"><i class="fa fa-list"></i>List Board Members</a></li>  
              </ul> 
        </li>
      </ul>
      <!-- /.sidebar-menu -->
    </section>