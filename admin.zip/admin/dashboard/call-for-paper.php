<?php error_reporting(1);
include ('header.php');
$lib = new library;
$hostname = $lib -> hostname();

if(isset($_POST['submit']) == 'Update' || $_POST['submit'] == 'Update'){
	$update = mysql_query("update callforpaper set volume='".$_POST['volume']."', number='".$_POST['number']."', year='".$_POST['year']."', lastDate='".$_POST['lastDate']."' where id = 1");
	if($update){
?>
<script>window.alert("Call for paper Updated successfully");</script>
<?php }else { ?>
<script>window.alert("OOps Something went wrong.. please try again");</script>
<?php } } 
?>

<aside class="main-sidebar">
	<?php
	include ("nav.php");
	?>
</aside>

<div class="content-wrapper">
	<section class="content-header">
		<h1>Call For Paper</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="active">
				Call For paper
			</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-6" style="padding-left:10px">
				<div class="box box-primary">
					<div id="modal"></div>
					<!--<div class="box-header">
					<h3 class="box-title">News & Updates</h3>
					</div>-->
					<!-- /.box-header -->

					<div class="box box-info col-md-6">
						<div class="box-header with-border">
							<h3 class="box-title">Horizontal Form</h3>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<?php $query = mysql_query("select * from callforpaper where id = 1");
						while ($data = mysql_fetch_array($query)) {
						?>

						<form class="form-horizontal" method="post" target="" enctype="multipart/form-data">
							<div class="box-body">
								<div class="form-group">
									<label for="inputEmail3" class="col-sm-2 control-label">Volume</label>
									<div class="col-sm-3">
										<input class="form-control" id="inputEmail3" placeholder="Volume" name="volume" type="number" value="<?php echo $data['volume']?>">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-2 control-label">Number</label>

									<div class="col-sm-3">
										<input class="form-control" id="inputPassword3" name="number" placeholder="Number" type="number" value="<?php echo $data['number']?>">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-2 control-label">Year</label>

									<div class="col-sm-3">
										<input class="form-control" id="inputPassword3" placeholder="Year" type="number" name="year" value="<?php echo $data['year']?>">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-2 control-label">Last Date</label>

									<div class="col-sm-3">
										<input class="form-control" id="inputPassword3" placeholder="Year" type="text" name="lastDate" value="<?php echo $data['lastDate']?>">
									</div>
								</div>

							</div>
							<!-- /.box-body -->
							<div class="box-footer">
								<input type="submit" name="submit" value="Update" class="btn btn-info pull-left" />
							</div>
							<!-- /.box-footer -->
						</form>
						<?php } ?>
					</div>
					<!-- /.box-body -->
				</div>
			</div>
		</div>
	</section>
</div>
<?php
include ('footer.php');
?>