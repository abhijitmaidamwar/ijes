<?php error_reporting(1);
include ('header.php');
$lib = new library;
$hostname = $lib -> hostname();

if(isset($_POST['submit']) == 'Add Member' || $_POST['submit'] == 'Add Member'){
	$Name=$_POST['name'];
	$category =$_POST['category'];
	$profession =$_POST['profession'];
	$designation =$_POST['designation'];
	$phone =$_POST['phone'];
	$email =$_POST['email'];
	$sequence =$_POST['sequence'];
	
	$insert = mysql_query("insert into boardmembers ( memberName, category, profession, designation, phone, email, sequence) 
	VALUES ('".$Name."', '".$category."', '".$profession."', '".$designation."', '".$phone."', '".$email."', '".$sequence."')");
	if($insert){
?>
<script>window.alert("Category added Successfully");</script>
<?php }else { ?>
<script>window.alert("OOps Something went wrong.. please try again");</script>
<?php } } ?>

<aside class="main-sidebar">
	<?php
	include ("nav.php");
	?>
</aside>

<div class="content-wrapper">
	<section class="content-header">
		<h1>Editorial Category</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="active">
				Editorial Category
			</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-6" style="padding-left:10px">
				<div class="box box-primary">
					<div id="modal"></div>
					<!--<div class="box-header">
					<h3 class="box-title">News & Updates</h3>
					</div>-->
					<!-- /.box-header -->

					<div class="box box-info col-md-6">
						<div class="box-header ">
							<h3 class="box-title">Editorial Category</h3>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						

						<form class="form-horizontal" method="post" target="" enctype="multipart/form-data">
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Board Member Name</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Member Name" type="text" name="name" required="">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Profession</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Profession" type="text" name="profession" required="">
									</div>
								</div>
							</div>
							
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Designation in IJIES</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Designation in IJIES" type="text" name="designation">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group ">
									<label for="inputPassword3" class="col-sm-4 control-label"> Board Category</label>
									<div class="col-sm-6">
									<select class="form-control" name="category">
										<?php $query = mysql_query("select * from boardcategory");
											  while ($data = mysql_fetch_array($query)) {
										?>
										<option value="<?php echo $data['id'] ?>"><?php echo $data['id']." - ". $data['categoryName'] ?></option>
										<?php }?>
									</select>
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Mobile No. / Phone No. </label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Contact Number" type="text" name="phone">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Email Id</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Email Id" type="text" name="email">
									</div>
								</div>
							</div>
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label"> Sequence</label>
									<div class="col-sm-6">
										<input class="form-control"  placeholder="sequence" type="text" name="sequence">
									</div>
								</div>
							</div>
							<!-- /.box-body -->
							<div class="box-footer">
								<input type="submit" name="submit" value="Add Member" class="btn btn-info pull-left" />
							</div>
							<!-- /.box-footer -->
						</form>
						
					</div>
					<!-- /.box-body -->
				</div>
			</div>

		</div>
	</section>
	
</div>
<?php
include ('footer.php');
?>