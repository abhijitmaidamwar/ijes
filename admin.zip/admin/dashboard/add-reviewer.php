<?php
error_reporting(0);
include("header.php");
$lib = new library;
$hostname = $lib->hostname();
$area = $lib->select("area",array("status" => 0));


if(isset($_POST['submit'])){
	
	$checkdata = array(
		"email" => $_POST['email']
	);
	
	$check = $lib->select('reviewers',$checkdata);
	
	if(empty($check)){
		$data = array(
			"name" => $_POST['name'],
			"email" => $_POST['email'],
			"password" => $_POST['password'],
			"epassword" => md5($_POST['password']),
			"contact" => $_POST['contact'],
			"other" => $_POST['other'],
			"area" => $_POST['area'],
			"status" => 0
		);
	
		$insert = $lib->insert('reviewers',$data);
	}
	
}

if(isset($_POST['update'])){
	
	$check = $lib->checkreviewers($_POST['email'],$_GET['editid']);
	
	if(empty($check)){
		$data = array(
			"name" => $_POST['name'],
			"email" => $_POST['email'],
			"password" => $_POST['password'],
			"epassword" => md5($_POST['password']),
			"contact" => $_POST['contact'],
			"other" => $_POST['other'],
			"area" => $_POST['area']
		);
	
		$update = $lib->update('reviewers',$_GET['editid'],$data);
	
}
}
if(isset($_GET['editid'])){
	
	$data = array(
			"id" => $_GET['editid']
		);
	
		$editrow = $lib->select('reviewers',$data);
		$editrow = $editrow[0];
}

?>
<aside class="main-sidebar">
  <?php include("nav.php"); ?>
</aside>


<div class="content-wrapper">
  <section class="content-header">
    <h1> Add Reviewer </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active">Add reviewer</li>
    </ol>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-8" style="padding-left:10px">
    
        <div class="box box-primary">
          <!--<div class="box-header with-border">
            <h3 class="box-title">Add News & Updates</h3>
          </div>-->
            
          <div class="box-body">
           <div class="form-group">
              <?php if(!empty($insert)) { ?>
					   <b class="text-green">Reviewer added successfully.</b>
					<?php	}  if(!empty($check)) { ?>
                         <b class="text-red">
                        		Sorry! Reviewer with same name or email is already exists.
                          </b>      
                    <?php }  if(!empty($update)) { ?>
					    <b class="text-green">
                        	Details are updated successfully.
                        </b>
				<?php	}  ?>
                </div>
                    <form method="post" enctype="multipart/form-data" onsubmit="return check();">
                    <div class="form-group">
                      <label>Name</label>
                        <input type="text" name="name" id="name" class="form-control" required="required" placeholder="Enter Name" value="<?php if(!empty($editrow)){ echo $editrow['name']; }?>" />
                    </div>
                    <div class="form-group">
                      <label>Email</label>
                        <input type="text" name="email" id="email" class="form-control" required="required" placeholder="Enter Email" value="<?php if(!empty($editrow)){ echo $editrow['email']; }?>" />
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                     <input type="password" name="password" id="password" class="form-control" required="required" placeholder="Enter Password" value="<?php if(!empty($editrow)){ echo $editrow['password']; }?>" />
                    </div>
                     <div class="form-group">
                      <label>Contact</label>
                         <input type="text" name="contact" id="contact" class="form-control" required="required" placeholder="Enter Contact No." value="<?php if(!empty($editrow)){ echo $editrow['contact']; }?>" />
                    </div>
                    <div class="form-group">
                      <label>Area</label> 
                         <select name="area" id="area" class="form-control" required="required">
                            <option value="">Select Area</option>
                                <?php foreach($area as $key => $val) { ?>
                                        <option value="<?php echo $val['sector']; ?>" <?php if($val['sector'] == $editrow['area']){?> selected="selected" <?php } ?>><?php echo $val['sector']; ?></option>
                                <?php } ?>
                         </select>
                    </div>
                    <div class="form-group">
                      <label>Other</label>
                         <input type="text" name="other" id="other" class="form-control" placeholder="Enter other fields" required="required" value="<?php if(!empty($editrow)){ echo $editrow['other']; }?>" />
                    </div>
                    <div class="form-group">
                    	<?php if(empty($editrow)){ ?>
                        	<input type="submit" name="submit" value="Submit" class="btn btn-primary btn-flat pull-right" />
                         <?php } else { ?>   
	                         <input type="submit" name="update" value="Update" class="btn btn-warning btn-flat pull-right" />
                         <?php } ?>
                    </div>
                    </form>
                   
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php include('footer.php'); ?>
<script>
  $(function () {
    $(".textarea").wysihtml5();
  });
</script>

<script>
	function check(){
		var title = $("#title");
		var desc = $("#desc");
		
		if(title.val() == ""){
			title.focus();
			title.addClass('validation');
			return false;
		}
		else{
			title.removeClass('validation');
		}
		
		if(desc.val() == ""){
			desc.focus();
			desc.addClass('validation');
			return false;
		}
		else{
			desc.removeClass('validation');
		}
		
		return true;
	}
</script>