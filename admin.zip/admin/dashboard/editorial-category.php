<?php error_reporting(1);
include ('header.php');
$lib = new library;
$hostname = $lib -> hostname();

if(isset($_POST['submit']) == 'Add Category' || $_POST['submit'] == 'Add Category'){
	$categoryName=$_POST['categoryName'];
	
	$insert = mysql_query("insert into boardcategory (categoryName) VALUES ('".$categoryName."')");
	if($insert){
?>
<script>window.alert("Category added Successfully");</script>
<?php }else { ?>
<script>window.alert("OOps Something went wrong.. please try again");</script>
<?php } } ?>

<aside class="main-sidebar">
	<?php
	include ("nav.php");
	?>
</aside>

<div class="content-wrapper">
	<section class="content-header">
		<h1>Editorial Board Category</h1>
		<ol class="breadcrumb">
			<li>
				<a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="active">
				Editorial Board Category
			</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-6" style="padding-left:10px">
				<div class="box box-primary">
					<div id="modal"></div>
					<!--<div class="box-header">
					<h3 class="box-title">News & Updates</h3>
					</div>-->
					<!-- /.box-header -->

					<div class="box box-info col-md-6">
						<div class="box-header ">
							<h3 class="box-title"> Board Category</h3>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						

						<form class="form-horizontal" method="post" target="" enctype="multipart/form-data">
							<div class="box-body">
								<div class="form-group">
									<label for="inputPassword3" class="col-sm-4 control-label">  Board Category Name</label>

									<div class="col-sm-6">
										<input class="form-control"  placeholder="Category Name" type="text" name="categoryName" required="">
									</div>
								</div>

							</div>
							<!-- /.box-body -->
							<div class="box-footer">
								<input type="submit" name="submit" value="Add Category" class="btn btn-info pull-left" />
							</div>
							<!-- /.box-footer -->
						</form>
						
					</div>
					<!-- /.box-body -->
				</div>
			</div>

		</div>
	</section>
	<section class="content col-md-6">
		<!-- section start-->
		<!-- SELECT2 EXAMPLE -->
		<div class="box box-default">
			<!-- box start start-->
			<div class="box-header with-border">
				<h3 class="box-title">Category List</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse">
						<i class="fa fa-minus"></i>
					</button>
					<button type="button" class="btn btn-box-tool" data-widget="remove">
						<i class="fa fa-remove"></i>
					</button>
				</div>
			</div>
			<!-- /.box-header -->

			<div class="box-body" style="text-transform: capitalize;">
				<div class="col-md-12  border-1px padding-10">
					<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">

						<div class="col-sm-12">
							<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
								<div class="row">
									<div class="col-sm-12">
										<table class="table  table-bordered table-striped dataTable no-footer" id="example1" role="grid" aria-describedby="example1_info">
											<thead>
												<tr role="row">
													<th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 90px;" aria-label="Name: activate to sort column descending" aria-sort="ascending">Category ID</th>
													<th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="User Type: activate to sort column ascending" style="width: 162px;">Category</th>

												</tr>
											</thead>
											<tbody>
													<?php $query = mysql_query("select * from boardcategory");
														  while ($data = mysql_fetch_array($query)) {
													?>
												<tr role="row" class="odd">
													<td class="sorting_1"><?php echo $data['id']; ?></td>
													<td><?php echo $data['categoryName']; ?></td>
												</tr>
												<?php }?>
											</tbody>
										</table>
									</div>
								</div>

							</div>
						</div>

					</div>
				</div>

			</div>

		</div>
	</section>
</div>
<?php
include ('footer.php');
?>