<?php
include('db.class.php');
date_default_timezone_set("Asia/Kolkata");
class library extends db{
	function hostname(){
		if($_SERVER['HTTP_HOST'] == 'localhost'){
			$hostname = "http://".$_SERVER['HTTP_HOST']."/journals/admin/";
		}
		else{
			$hostname = "http://".$_SERVER['HTTP_HOST']."/admin/";
		}
		
		return($hostname);
	}
	
	function hostmain(){
		if($_SERVER['HTTP_HOST'] == 'localhost'){
			$hostmain = "http://".$_SERVER['HTTP_HOST']."/journals/";
		}
		else{
			$hostmain = "http://".$_SERVER['HTTP_HOST']."/";
		}
		
		return($hostmain);
	}
	
	function filename(){
		$url = $_SERVER['REQUEST_URI'];
		$path_parts = pathinfo($url);
		$pagename = $path_parts['basename'];
		return($pagename);
	}
	
	function server(){
		return($_SERVER);
	}
	
	function get_content()
	{
		//echo $_GET['url'];
		$pg = explode("/",$_GET['url']);
		//print_r($pg);
		list($p,$ext) = explode('.',$pg[0]);
		$page = $p?$p:'index';
		if(file_exists('pages/'.$page.'.php'))
		{
			include('pages/'.$page.'.php');
		}
		else
		{
			include('pages/404.php');
		}
	}
	
	function get_title()
	{
		if($_GET['url'])
		{
			list($p,$ext) = explode('.',$_GET['url']);
			$t = str_replace('-',' ',$p);
			$s = ucwords($t) . ' | KRIMS Hospitals';
			return($s); 
		}
		else
		{
			return('Welcome to Admin');
		}
	}
	
	function get_css()
	{
		include('assets/css.php');
	}
	
	function get_js(){
		include('assets/js.php');
	}
	
	function insert($tablename,$data){
		foreach($data as $keys => $val){
			$fields[] = $keys;
			$values[] = $val;
		}
		$fieldsa = implode(", ",$fields);
		$valuesa = implode("', '",$values);
		$res = mysql_query("INSERT INTO " . $tablename  . " (" . $fieldsa . ") VALUES ('" . $valuesa . "')");		
		return($res);
	}	
	
	function select($tablename,$conditions = NULL,$condimanage = NULL,$olmanage = NULL,$columns = NULL){
		if($columns == NULL){
			$columns = "*";
		}
		$where = "WHERE";
		if(!empty($conditions)){
			$level = count($conditions);
			foreach ($conditions as $key => $value) {		
				if($level > 1){
					$condi[] = $key . " = '" . $value . "' " . $condimanage;
					$level--;
				}
				elseif ($level == 1) {
					$condi[] = $key . " = '" . $value . "' ";
				}
				else{
					$condi[] = $key . " = '" . $value . "'";
				}
			}
			$cond = implode(" ",$condi);
			$mquery = "SELECT " . $columns . " FROM " . $tablename . " " . $where ." " . $cond . " " . $olmanage . " ";
		}
		else{
			$mquery = "SELECT " . $columns . " FROM " . $tablename . " " . $olmanage . " ";
		}
		$query = mysql_query($mquery);
		
		while($row = mysql_fetch_assoc($query)){
			$res[] = $row; 
		}
		
		return($res);
	}
	
	function randnoGen(){
		$no = "PCB".date('ymdHis');
		$lastrnofetch = mysql_query("SELECT cno,entry FROM complaintbox ORDER BY id DESC LIMIT 1");
		$lastrno = mysql_fetch_assoc($lastrnofetch);
		
		$lastdttime = explode(" ",$lastrno['entry']);
		$lastdt = $lastdttime[0];
		
		if(date('Y-m-d') > $lastdt){
			$reset = "0001";
			$rno = $no.$reset;
		} 
		else{
			$srno = substr($lastrno['cno'],15,19);
			$srno++;
			$length = 4-strlen($srno);
			for($i=0;$i<$length; $i++){
				$zeros .='0';
			}
			$srno = $zeros.$srno;
			$rno = $no.$srno;
		}
		
		return($rno);
	}
	
	function fileupload($extentions,$filename,$filetype,$fileerror,$filesize,$filetmpname,$namechanger,$dirupload){
		$allowedExts = $extentions; //"gif", "jpeg", "jpg", "png"
		$temp = explode(".", $filename); //$_FILES["file"]
		$extension = end($temp);
		
		if ((($filetype == "image/gif") || ($filetype == "image/jpeg") || ($filetype == "image/jpg") || ($filetype == "image/pjpeg") || ($filetype == "image/x-png") || ($filetype == "image/png")) && ($filesize < 200000000) && in_array($extension, $allowedExts,true)) {
		  if ($fileerror > 0) {
		      $res = "Return Code: " . $fileerror . "<br>";
			  $res = 0;
		  } else {
		    // echo "Upload: " . date("HisdmY").$filename . "<br>";
		    // echo "Type: " . $filetype . "<br>";
		    // echo "Size: " . ($filesize / 1024) . " kB<br>";
		    // echo "Temp file: " . $filetmpname . "<br>";
		    if (file_exists($dirupload . $namechanger.$filename)) {
		      	$res = date("HisdmY").$filename . " already exists. ";
				$res = 2;
		    } else {
		      move_uploaded_file($filetmpname, $dirupload . $namechanger.$filename);
		      $res = "Stored in: " . $dirupload . $namechanger.$filename;
			  $res = 1;
		    }
		  }
		} else {
			$res = "Invalid file";
		  	$res = 0;
		}		
		
		return($res);
	}
	
}
?>
